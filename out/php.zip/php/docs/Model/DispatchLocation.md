# # DispatchLocation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**energy** | **float** | Percentage of energy | [optional]
**location** | **object** | GeoJSON encoded location of target or source of green energy. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
