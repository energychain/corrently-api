# # InlineResponse2002Timeframe

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **int** | Starting time of window evaluated in order to get dispatches | [optional]
**end** | **int** | Ending time of window evaluated for this request/dispatches. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
