# # InlineResponse2001Location

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zip** | **string** | Zipcode (Postleitzahl) | [optional]
**city** | **string** | Pretty Print city name | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
