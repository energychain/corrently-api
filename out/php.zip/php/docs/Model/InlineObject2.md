# # InlineObject2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **string** | Stromkonto account address of sender | [optional]
**to** | **string** | Stromkonto account address of reciever | [optional]
**value** | **int** | Amount to transfer (in Watthours for electricity, or pcs for trees) | [optional]
**variation** | **string** |  | [optional]
**signature** | **string** | Signature per Stromkonto setting (might be simple email confirmation link) | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
