# # Componentsh0

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sum** | **double** | Total sum in Euro for this price component. | [optional]
**describtion** | **string** | What is this price component about | [optional]
**mutlityplier** | **string** | Frequency/dependency of component | [optional]
**per** | **double** | Single unit price multiyplier is based on | [optional]
**components** | [**\OpenAPI\Client\Model\Componentsh0[]**](Componentsh0.md) | Sub components of this price | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
