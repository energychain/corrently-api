# # InlineResponse2001MatrixH0

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avg_1** | **string** | device should run in 1 hour | [optional]
**avg_2** | **string** | device should run in 2 hours | [optional]
**avg_3** | **string** | device should run in 3 hour | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
