# # MarketData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_timestamp** | **int** | Timestamp in Standard Milliseconds | [optional]
**end_timestamp** | **int** | Timestamp in Standard Milliseconds | [optional]
**marketprice** | **float** | Actual Marketprice for regional green power in EUR per MWh | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
