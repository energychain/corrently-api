# # Tariffh0

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ap** | **int** | Energy price in cent per kwh. (Arbeitspreis) including all taxes and fees. | [optional]
**gp** | **int** | Base price in euro per montah (Grundpreis) including all taxes and fees. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
