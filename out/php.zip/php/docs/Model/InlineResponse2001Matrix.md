# # InlineResponse2001Matrix

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**h0** | [**\OpenAPI\Client\Model\InlineResponse2001MatrixH0**](InlineResponse2001MatrixH0.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
