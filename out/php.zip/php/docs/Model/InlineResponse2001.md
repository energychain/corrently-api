# # InlineResponse2001

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**forecast** | [**\OpenAPI\Client\Model\ForecastItem[]**](ForecastItem.md) | Prediction for the upcomming hours | [optional]
**location** | [**\OpenAPI\Client\Model\InlineResponse2001Location**](InlineResponse2001Location.md) |  | [optional]
**matrix** | [**\OpenAPI\Client\Model\InlineResponse2001Matrix**](InlineResponse2001Matrix.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
