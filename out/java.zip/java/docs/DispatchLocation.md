

# DispatchLocation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**energy** | **BigDecimal** | Percentage of energy |  [optional]
**location** | **Object** | GeoJSON encoded location of target or source of green energy. |  [optional]



