

# InlineResponse2001Matrix

Device switching recommendation.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**h0** | [**InlineResponse2001MatrixH0**](InlineResponse2001MatrixH0.md) |  |  [optional]



