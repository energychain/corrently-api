

# MarketData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startTimestamp** | **Integer** | Timestamp in Standard Milliseconds |  [optional]
**endTimestamp** | **Integer** | Timestamp in Standard Milliseconds |  [optional]
**marketprice** | **BigDecimal** | Actual Marketprice for regional green power in EUR per MWh |  [optional]



