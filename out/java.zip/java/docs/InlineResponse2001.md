

# InlineResponse2001


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**forecast** | [**List&lt;ForecastItem&gt;**](ForecastItem.md) | Prediction for the upcomming hours |  [optional]
**location** | [**InlineResponse2001Location**](InlineResponse2001Location.md) |  |  [optional]
**matrix** | [**InlineResponse2001Matrix**](InlineResponse2001Matrix.md) |  |  [optional]



