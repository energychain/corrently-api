

# Tariffh0


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ap** | **Integer** | Energy price in cent per kwh. (Arbeitspreis) including all taxes and fees. |  [optional]
**gp** | **Integer** | Base price in euro per montah (Grundpreis) including all taxes and fees. |  [optional]



