

# InlineResponse2002Timeframe

Evaluated timeframe for this request

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **Integer** | Starting time of window evaluated in order to get dispatches |  [optional]
**end** | **Integer** | Ending time of window evaluated for this request/dispatches. |  [optional]



