

# InlineResponse200


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**StatusEnum**](#StatusEnum) | Registration status of a user. In case unregistered gets returned use the &#x60;register&#x60; endpoint to (re-)register. |  [optional]



## Enum: StatusEnum

Name | Value
---- | -----
REGISTERED | &quot;registered&quot;
UNREGISTERED | &quot;unregistered&quot;



