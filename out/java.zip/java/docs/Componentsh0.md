

# Componentsh0


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sum** | **Double** | Total sum in Euro for this price component. |  [optional]
**describtion** | **String** | What is this price component about |  [optional]
**mutlityplier** | **String** | Frequency/dependency of component |  [optional]
**per** | **Double** | Single unit price multiyplier is based on |  [optional]
**components** | [**List&lt;Componentsh0&gt;**](Componentsh0.md) | Sub components of this price |  [optional]



