

# InlineResponse2001Location

Standarized location info sourced for prediction

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zip** | **String** | Zipcode (Postleitzahl) |  [optional]
**city** | **String** | Pretty Print city name |  [optional]



