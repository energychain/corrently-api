

# InlineResponse2003


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;MarketData&gt;**](MarketData.md) | Energyprice for the upcomming hours |  [optional]



