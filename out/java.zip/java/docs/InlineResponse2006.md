

# InlineResponse2006


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wimStatus** | **String** | Latest Status |  [optional]
**wimStarted** | **Integer** | Starting time of process |  [optional]



