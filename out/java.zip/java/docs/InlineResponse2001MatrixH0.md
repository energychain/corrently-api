

# InlineResponse2001MatrixH0

Indicates number of hours a device should run

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avg1** | **String** | device should run in 1 hour |  [optional]
**avg2** | **String** | device should run in 2 hours |  [optional]
**avg3** | **String** | device should run in 3 hour |  [optional]



