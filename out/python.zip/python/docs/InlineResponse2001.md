# InlineResponse2001


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**forecast** | [**[ForecastItem]**](ForecastItem.md) | Prediction for the upcomming hours | [optional] 
**location** | [**InlineResponse2001Location**](InlineResponse2001Location.md) |  | [optional] 
**matrix** | [**InlineResponse2001Matrix**](InlineResponse2001Matrix.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


