# Componentsh0


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sum** | **float** | Total sum in Euro for this price component. | [optional] 
**describtion** | **str** | What is this price component about | [optional] 
**mutlityplier** | **str** | Frequency/dependency of component | [optional] 
**per** | **float** | Single unit price multiyplier is based on | [optional] 
**components** | [**[Componentsh0]**](Componentsh0.md) | Sub components of this price | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


